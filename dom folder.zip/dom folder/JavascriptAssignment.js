// JavaScript source code
document.getElementById("googleid").setAttribute("href", "https://www.google.com");
document.getElementById("twitterid").setAttribute("href", "https://www.twitter.com");
document.getElementById("slackid").setAttribute("href", "https://www.slack.com");
document.getElementById("javadocsid").setAttribute("href", "https://www.javadoc.com");


document.getElementById("planet").options[3].setAttribute("disabled", "true");

function alienText(value) {
    if (value == "mars") {
        document.getElementById("planetMessage").innerHTML = "Greetings Marsling";

    } else if (value == "proximaCentauri") {
        document.getElementById("planetMessage").innerHTML = "Greetings Proximian";


    } else {
        document.getElementById("planetMessage").innerHTML = "Greetings Earthling";


    }



}


function additionalData() {
    let fname = document.getElementById("firstname").value;

    let lname = document.getElementById("lastname").value;

    let email = document.getElementById("email").value;

    let genders = document.getElementsByName("gender");

    let g;
    for (let i = 0; i < genders.length;i++) {
        if (genders[i].checked)
            g = genders[i].value;
    }

    let phone = document.getElementById("phone").value;


    let birthday = document.getElementById("bday").value;
    let color = document.getElementById("color").value;

    let activities = document.getElementsByClassName("activity");
//    console.log(activities);

    let selectedActivities=[];
    for (let i = 0; i < activities.length; i++) {
        if (activities[i].checked)
            selectedActivities.push(activities[i].value);
    }

//    console.log(selectedActivities);

//    console.log("firstname: " + fname + " lastname: " + lname);
//    console.log("email: " + email + " phone: " + phone);
//    console.log("gender: " + g + " color: " + color);
//    console.log("bday: " + birthday);

    let newtr = document.createElement("tr");

    let newtd = document.createElement("td");
    var text = document.createTextNode(fname);
    newtd.appendChild(text);
    newtr.appendChild(newtd);

    let newtd1 = document.createElement("td");
    var text1 = document.createTextNode(email);
    newtd1.appendChild(text1);
    newtr.appendChild(newtd1);

    let newtd2 = document.createElement("td");
    var text2 = document.createTextNode(phone);
    newtd2.appendChild(text2);
    newtr.appendChild(newtd2);

    let newtd3 = document.createElement("td");
    var text3 = document.createTextNode(birthday);
    newtd3.appendChild(text3);
    newtr.appendChild(newtd3);

    let newtd4 = document.createElement("td");
    var text4 = document.createTextNode(color);
    newtd4.appendChild(text4);
    newtr.appendChild(newtd4);


    let newtd5 = document.createElement("td");
    var text5 = document.createTextNode(g);
    newtd5.appendChild(text5);
    newtr.appendChild(newtd5);

    let newtd6 = document.createElement("td");
    let newul = document.createElement("ul");
    for (let i = 0; i < selectedActivities.length; i++) {
        let newli = document.createElement("li");
        let textLI = document.createTextNode(selectedActivities[i]);
        newli.appendChild(textLI);
        newul.appendChild(newli);
    }
    newtd6.appendChild(newul);
    newtr.appendChild(newtd6);

    let table = document.getElementsByTagName("table")[0];
    table.appendChild(newtr);

//    console.log(newtr);
//    console.log(table);

}


let details = document.getElementsByTagName("details")[0];
details.addEventListener("mouseover", openDetails);

function openDetails() {
    if (!details.hasAttribute("open")) details.setAttribute("open", true);
}



function innerHTML() {
    let s = "";
    let spans = document.getElementsByTagName("span");
    for (let i = 0; i < spans.length; i++) {
        s += spans[i].firstChild.nodeValue;
    }
    console.log(s);

}

innerHTML();


let etcheck = document.getElementById("earth_time_check");

etcheck.addEventListener("click", timeEarth);

function timeEarth() {
    document.getElementById('earth_time').innerHTML = "Earth time: " + Date();

}


let ptcheck = document.getElementsByTagName("h1")[0];
ptcheck.addEventListener("click", changeBackground );


function changeBackground() {
    document.body.style.backgroundColor= "#239002";
}


let str = "Hey now, brown cow.";

function removeChar(arg1, arg2) {
    let s;
    s = arg1.slice(0, arg2) + arg1.slice(arg2 + 1, arg1.length);
    return s;
}

let x = [1, 3, 33, 55, 9, 9, 2, 5, 5, 80];

function bubbleSort(arg) {
    let l = arg.length;
    let t = 0;
    let n = arg;


    for (let i = 0; i < l; i++) {
        for (let j = 1; j < (l - i); j++) {
            if (n[j - 1] > n[j]) {
                t = n[j - 1];
                n[j - 1] = n[j];
                n[j] = t;

            }
        }
    }
    return n;
}

console.log(bubbleSort(x));


let num = 192;
let num2 = 91;

function isEven(arg) {
    let n = arg;
    let t = n;
    while (t > 1) {
        t -= 2;
    }
    if (t === 1) {
        return false;
    } else return true;
}

console.log(isEven(num));
console.log(isEven(num2));


let pal = "kajdsqpoakms";
let npal = "qpmznsjw";

function isPalendrome(arg1, arg2) {
    arg2 = arg1.length;
    for (let i = 0; i < (arg2 / 2); ++i) {
        if (arg1.charAt(i) !== arg1.charAt(arg2 - i - 1)) {
            return false;
        }
    }
    return true;
}

console.log(isPalendrome(npal));
console.log(isPalendrome(pal));