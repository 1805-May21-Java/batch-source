package com.revature.dao;

import java.util.List;

import com.revature.pojos.User;

public interface UserDao {
	
	public List<User> getUser();
	public User getUserByEmail(String e);
	public int createUser(User u);
	public int updateUserEmail(User u, String e);
	public int deleteUserByEmail(String e);

}
