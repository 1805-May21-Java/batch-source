package com.revature.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.revature.pojos.Account;
import com.revature.util.ConnectionUtil;

public class AccountDaoImpl implements AccountDao {

	public List<Account> getAccount() {
		List<Account> accountList = new ArrayList<Account>();
		
		try {
			Connection con = ConnectionUtil.getConnection();
			String sql = "SELECT * FROM BS_ACCOUNT";
			PreparedStatement s = con.prepareStatement(sql);
			ResultSet rs = s.executeQuery();
			
			while(rs.next()) {
				String email = rs.getString("EMAIL");
				String password = rs.getString("PW");
				double balance = rs.getDouble("BALANCE");
				accountList.add( new Account(balance,password,email));
			}
			
			con.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return accountList;
	}


	public Account getAccountByEm(String em) {
		Account a = null;
		
		try {
			Connection con = ConnectionUtil.getConnection();
			String sql = "SELECT * FROM BS_ACCOUNT WHERE EMAIL = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, em);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				String email = rs.getString("EMAIL");
				String password = rs.getString("PW");
				double bal = rs.getDouble("BALANCE");
				a = new Account(bal,email,password);
			}
			
			con.close();

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return a;

	}

	public int createAccount(Account a) {
		int accountCreated = 0;
		
		try {
			Connection con = ConnectionUtil.getConnection();
			String sql = "INSERT INTO BS_ACCOUNT (EMAIL, PW, BALANCE) VALUES (?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, a.getAccount());
			ps.setString(2, a.getPassword());
			ps.setDouble(3, a.getBalance());
			accountCreated = ps.executeUpdate();
			con.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accountCreated;
	}

	public int updateAccount(Account a, String em) {
		int accountUpdated = 0;
		String sql = "UPDATE BS_ACCOUNT "
				+ "SET EMAIL = ?, "
				+ "PASSWORD = ?, "
				+ "BALANCE = ?"
				+ "WHERE EMAIL = ?";
		try {
			Connection con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pstatement = con.prepareStatement(sql);
			pstatement.setString(1, a.getAccount());
			pstatement.setString(2, a.getPassword());
			pstatement.setDouble(3, a.getBalance());
			pstatement.setString(4, em);

			accountUpdated = pstatement.executeUpdate();
			con.commit();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountUpdated;

	}

	public int deleteAccountByEmail(String em) {
		int rowsUpdated = 0;
		
		String sql = "DELETE FROM BS_ACCT WHERE EMAIL = ?";
		
		try {
			Connection con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pstatement = con.prepareStatement(sql);
			pstatement.setString(1, em);	
			rowsUpdated = pstatement.executeUpdate();
			con.commit();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return rowsUpdated;
	}


	public int updateWithdrawalAccount(Account a, int m) {
		int accountUpdated = 0;
		String sql = "UPDATE BS_ACCOUNT "
				+ "SET BALANCE = ?"
				+ "WHERE EMAIL = ?";
		try {
			Connection con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pstatement = con.prepareStatement(sql);
			pstatement.setDouble(1, a.getBalance() - m);
			pstatement.setString(2, a.getAccount());

			accountUpdated = pstatement.executeUpdate();
			con.commit();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountUpdated;
	}

	
	public int updateDepositAccount(Account a, int m) {
		int accountUpdated = 0;
		String sql = "UPDATE BS_ACCOUNT "
				+ "SET BALANCE = ?"
				+ "WHERE EMAIL = ?";
		try {
			Connection con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pstatement = con.prepareStatement(sql);
			pstatement.setDouble(1, a.getBalance() + m);
			pstatement.setString(2, a.getAccount());

			accountUpdated = pstatement.executeUpdate();
			con.commit();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountUpdated;
	}

}
