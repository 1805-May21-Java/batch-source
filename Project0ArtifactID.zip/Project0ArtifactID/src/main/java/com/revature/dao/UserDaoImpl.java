package com.revature.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.revature.pojos.User;
import com.revature.util.ConnectionUtil;

public class UserDaoImpl implements UserDao {

	public List<User> getUser() {
		List<User> userList = new ArrayList<User>();
		
		try {
			Connection con = ConnectionUtil.getConnection();
			String sql = "SELECT * FROM BS_USER";
			PreparedStatement s = con.prepareStatement(sql);
			ResultSet rs = s.executeQuery();
			
			while(rs.next()) {
				String email = rs.getString("EMAIL");
				String password = rs.getString("PW");
				userList.add( new User(email,password));
			}
			
			con.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return userList;
	}

	public User getUserByEmail(String em) {
		User u = null;
		
		try {
			Connection con = ConnectionUtil.getConnection();
			String sql = "SELECT * FROM BS_USER WHERE EMAIL = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, em);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				String email = rs.getString("EMAIL");
				String password = rs.getString("PW");
				u = new User(email,password);
			}
			
			con.close();

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return u;
	}

	public int createUser(User u) {
		int userCreated = 0;
		
		try {
			Connection con = ConnectionUtil.getConnection();
			String sql = "INSERT INTO BS_USER (EMAIL, PW) VALUES (?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, u.getEmail());
			ps.setString(2, u.getPassword());
			userCreated = ps.executeUpdate();
			con.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userCreated;
	}

	public int updateUserEmail(User u, String em) {
		int userUpdated = 0;
		String sql = "UPDATE BS_USER "
				+ "SET EMAIL = ? "
				+ "WHERE EMAIL = ?";
		try {
			Connection con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pstatement = con.prepareStatement(sql);
			pstatement.setString(1, u.getEmail());
			pstatement.setString(3, em);

			userUpdated = pstatement.executeUpdate();
			con.commit();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userUpdated;
	}

	public int deleteUserByEmail(String em) {
		int rowsUpdated = 0;
		
		String sql = "DELETE FROM BS_USER WHERE EMAIL = ?";
		
		try {
			Connection con = ConnectionUtil.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pstatement = con.prepareStatement(sql);
			pstatement.setString(1, em);	
			rowsUpdated = pstatement.executeUpdate();
			con.commit();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return rowsUpdated;
	}




}
