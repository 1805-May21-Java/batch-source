package com.revature.dao;

import java.util.List;

import com.revature.pojos.Account;

public interface AccountDao {

	public List<Account> getAccount();
	public Account getAccountByEm(String e);
	public int createAccount(Account a);
	public int updateAccount(Account a, String e);
	public int deleteAccountByEmail(String e);
	public int updateWithdrawalAccount(Account a, int m);
	public int updateDepositAccount(Account a, int m);
	
}
